#include <rsync.h>

#define curr_dir GetThreadData()->curr_dir
#define curr_dir_len GetThreadData()->curr_dir_len

int renamewin32( const char *oldname, const char *newname )
{
	int iLen = 0;
	char oldfullpath[MAXPATHLEN];
	char newfullpath[MAXPATHLEN];
	if( oldname[0] != '/' )
	{
		strncpy(oldfullpath, curr_dir, sizeof(oldfullpath)-2);
		iLen = strlen(oldfullpath);
		if( oldfullpath[iLen-1] != '/' )
		{
			oldfullpath[iLen++] = '/';
			oldfullpath[iLen] = 0;
		}
		strncat(oldfullpath, oldname, sizeof(oldfullpath) - 1 - iLen);
		oldname = oldfullpath;
	}

	if( newname[0] != '/' )
	{
		strncpy(newfullpath, curr_dir, sizeof(newfullpath)-2);
		iLen = strlen(newfullpath);
		if( newfullpath[iLen-1] != '/' )
		{
			newfullpath[iLen++] = '/';
			newfullpath[iLen] = 0;
		}
		strncat(newfullpath, newname, sizeof(newfullpath) - 1 - iLen);
		newname = newfullpath;
	}

	return rename(oldname, newname);
}