/* 
   Copyright (C) 2005 by George McCollister
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

/*
  GMM - 3/16/2005
  This is code is central to the design of my Win32 port.
  Otherwise static and global variables are managed here in
  a thread safe fashion.
*/
#include <rsync.h>
#include <popt.h>

#define IsTlsIndexGood(index) (index != MAXDWORD)

static DWORD g_dwTLSIndex = MAXDWORD;

/*
  GMM - 3/16/2005
  Get pointer to the thread data structure.
  If the data doesn't exist, call CreateThreadDataFromParent
  to create a new data structure for this thread.
*/
struct thread_data * GetThreadData(void)
{
	struct thread_data * pReturn = GetThreadDataRaw();
	if( !pReturn )
		pReturn = CreateThreadDataFromParent(NULL);
	
	return pReturn;
}

/*
  GMM - 3/16/2005
  Get pointer to the thread data structure.
  Return null if it doesn't exist.
*/
struct thread_data * GetThreadDataRaw(void)
{
	struct thread_data * pReturn = NULL;

	if( IsTlsIndexGood(g_dwTLSIndex) )
	{
		pReturn = (struct thread_data *) TlsGetValue(g_dwTLSIndex);
	}

	return pReturn;
}

/*
  GMM - 3/16/2005
  Create a new data structure to handle thread unique data.
  Alloc a Tls index if one doesn't exist.
  If data exists, copy data from the parent thread, otherwise set to
  safe initial values.
*/
struct thread_data * CreateThreadDataFromParent(struct thread_data * pParentData)
{	
	struct thread_data * pThreadData = NULL;

	if( !IsTlsIndexGood(g_dwTLSIndex) )
	{
		g_dwTLSIndex = TlsAlloc();
		if( !IsTlsIndexGood(g_dwTLSIndex) )
			out_of_memory("CreateThreadDataFromParent: TlsAlloc");
	}

	pThreadData = (struct thread_data *) GlobalAlloc(0, sizeof(struct thread_data));
	ZeroMemory(pThreadData, sizeof(struct thread_data));

	if( !TlsSetValue(g_dwTLSIndex, pThreadData) )
		out_of_memory("CreateThreadDataFromParent: TlsSetValue");
	
	if( pParentData )
	{
		pThreadData->io_multiplexing_in = pParentData->io_multiplexing_in;
		pThreadData->io_multiplexing_out = pParentData->io_multiplexing_out;
		
		if( pParentData->iobuf_out )
		{
			if (!(pThreadData->iobuf_out = new_array(char, IO_BUFFER_SIZE)))
				out_of_memory("CreateThreadDataFromParent: new_array");

			memcpy(pThreadData->iobuf_out, pParentData->iobuf_out, IO_BUFFER_SIZE);
		}

		pThreadData->iobuf_out_cnt = pParentData->iobuf_out_cnt;

		pThreadData->iobuf_in_siz = pParentData->iobuf_in_siz;
		if( pParentData->iobuf_in )
		{
			if (!(pThreadData->iobuf_in = new_array(char, pThreadData->iobuf_in_siz)))
				out_of_memory("CreateThreadDataFromParent: new_array");

			memcpy(pThreadData->iobuf_in, pParentData->iobuf_in, pThreadData->iobuf_in_siz);
		}
		
		pThreadData->iobuf_in_remaining = pParentData->iobuf_in_remaining;
		pThreadData->iobuf_in_ndx = pParentData->iobuf_in_ndx;

		pThreadData->no_flush = pParentData->no_flush;

		pThreadData->old_msg_fd_in = -1;
		pThreadData->msg_fd_in = pParentData->msg_fd_in;
		pThreadData->msg_fd_out = pParentData->msg_fd_out;
		pThreadData->thread_fd_in = pParentData->thread_fd_in;
		pThreadData->thread_fd_out = pParentData->thread_fd_out;
		pThreadData->sock_f_in = pParentData->sock_f_in;
		pThreadData->sock_f_out = pParentData->sock_f_out;

		pThreadData->stats = pParentData->stats;

		if( pParentData->tag_table != NULL )
		{
			rprintf(FERROR, "DEBUG ERROR. pParentData->tag_table != 0\n");
			exit(0);
		}

		if( pParentData->targets != NULL )
		{
			rprintf(FERROR, "DEBUG ERROR. pParentData->targets != 0\n");
			exit(0);
		}

		strncpy(pThreadData->curr_dir, pParentData->curr_dir, sizeof(pThreadData->curr_dir)-1);
		pThreadData->curr_dir_len = pParentData->curr_dir_len;

		copy_exclude_list(&pThreadData->exclude_list, &pParentData->exclude_list);
		copy_exclude_list(&pThreadData->local_exclude_list, &pParentData->local_exclude_list);
		copy_exclude_list(&pThreadData->server_exclude_list, &pParentData->server_exclude_list);

		pThreadData->exclude_path_prefix = NULL;
		if( pParentData->exclude_path_prefix )
		{
			pThreadData->exclude_path_prefix = new_array(char, strlen(pParentData->exclude_path_prefix)+1);
			strcpy(pThreadData->exclude_path_prefix, pParentData->exclude_path_prefix);
		}

		pThreadData->csum_length = pParentData->csum_length;
		pThreadData->checksum_seed = pParentData->checksum_seed;
		pThreadData->protocol_version = pParentData->protocol_version;
		pThreadData->sumresidue = pParentData->sumresidue;
		memcpy(pThreadData->sumrbuf, pParentData->sumrbuf, sizeof(pThreadData->sumrbuf));
		pThreadData->md = pParentData->md;
		pThreadData->last_match = pParentData->last_match;
		pThreadData->last_byte = pParentData->last_byte;
		pThreadData->last_sparse = pParentData->last_sparse;
		pThreadData->m = 0;
		pThreadData->wf_writeBuf = pParentData->wf_writeBuf;
		pThreadData->wf_writeBufSize = pParentData->wf_writeBufSize;
		pThreadData->wf_writeBufCnt = pParentData->wf_writeBufCnt;
		pThreadData->srt_residue = pParentData->srt_residue;
		pThreadData->srt_buf = pParentData->srt_buf;
		pThreadData->sdt_init_done = pParentData->sdt_init_done;
		pThreadData->sdt_flush_pending = pParentData->sdt_flush_pending;
		pThreadData->rdt_init_done = pParentData->rdt_init_done;
		pThreadData->rdt_saved_flag = pParentData->rdt_saved_flag;

		if( pParentData->cs2_buf1 && pParentData->cs2_len1 )
		{ 
			pThreadData->cs2_buf1 = new_array(char, pParentData->cs2_len1);
			memcpy(pThreadData->cs2_buf1, pParentData->cs2_buf1, pParentData->cs2_len1);
			pThreadData->cs2_len1 = pParentData->cs2_len1;
		}

		pThreadData->pc = 0;

		if( pParentData->bufr )
		{
			pThreadData->bufr = new_array(char, pParentData->bSize);
			memcpy(pThreadData->bufr, pParentData->bufr, pParentData->bSize);
			pThreadData->bSize = pParentData->bSize;
		}

		pThreadData->received_flist = 0;

		pThreadData->rsync_module_argv = 0;
		pThreadData->rsync_module_argc = 0;
		pThreadData->parm_table = dup_new_parm_table(pParentData->parm_table);		
		
		pThreadData->iNumServices = pParentData->iNumServices;
		pThreadData->iServiceIndex = pParentData->iServiceIndex;
		pThreadData->bInGlobalSection = pParentData->bInGlobalSection;
		pThreadData->ServicePtrs = dup_services(pParentData->ServicePtrs, pParentData->iNumServices);
		pThreadData->pstartrecvfilesstruct = NULL;
		pThreadData->pstartfnstruct = NULL;
		pThreadData->io_timeout = pParentData->io_timeout;
		pThreadData->long_options = dup_options(pParentData->long_options);
		pThreadData->cleanup_got_literal = pParentData->cleanup_got_literal;
		
		if( pParentData->cleanup_fname )
			pThreadData->cleanup_fname = strdup(pParentData->cleanup_fname);
		
		if( pParentData->cleanup_new_fname )
			pThreadData->cleanup_new_fname = strdup(pParentData->cleanup_new_fname);

		if( pParentData->cleanup_file )
		{
			pThreadData->cleanup_file = new_array(char, sizeof(struct file_struct));
			memcpy(pThreadData->cleanup_file, pParentData->cleanup_file, sizeof(struct file_struct));
		}

		pThreadData->cleanup_fd_r = pParentData->cleanup_fd_r;
		pThreadData->cleanup_fd_w = pParentData->cleanup_fd_w;
		pThreadData->cleanup_pid = pParentData->cleanup_pid;
		pThreadData->verbose = pParentData->verbose;
		pThreadData->inside_cleanup = 0;
		pThreadData->last_io = pParentData->last_io;
		pThreadData->msg_list_push_written = pParentData->msg_list_push_written;
		pThreadData->io_error = pParentData->io_error;

		pThreadData->bwlimit_prior_tv = pParentData->bwlimit_prior_tv;
		pThreadData->bwlimit_total_written = pParentData->bwlimit_total_written; 
		pThreadData->bwlimit_tv = pParentData->bwlimit_tv;
		pThreadData->bwlimit_start_tv = pParentData->bwlimit_start_tv;
		pThreadData->bwlimit_elapsed_usec = pParentData->bwlimit_elapsed_usec;
		pThreadData->bwlimit_sleep_usec = pParentData->bwlimit_sleep_usec;
		pThreadData->am_sender = pParentData->am_sender;	

		pThreadData->sfe_modtime = 0;
		pThreadData->sfe_mode = 0;
		pThreadData->sfe_dev = 0;
		pThreadData->sfe_rdev = 0;
		pThreadData->sfe_rdev_major = 0;
		pThreadData->sfe_uid = 0;
		pThreadData->sfe_gid = 0;		
		//pThreadData->sfe_lastname //cleared by memset don't bother clearing it again.

		pThreadData->rfe_modtime = 0;
		pThreadData->rfe_mode = 0;
		pThreadData->rfe_dev = 0;
		pThreadData->rfe_rdev = 0;
		pThreadData->rfe_rdev_major = 0;
		pThreadData->rfe_uid = 0;
		pThreadData->rfe_gid = 0;
		//pThreadData->rfe_lastname //cleared by memset don't bother clearing it again.
		pThreadData->rfe_lastdir = 0;
		pThreadData->rfe_lastdir_depth = 0;
		pThreadData->rfe_lastdir_len = -1;

		pThreadData->dry_run = pParentData->dry_run;
		pThreadData->sparse_files = pParentData->sparse_files;
		pThreadData->cvs_exclude = pParentData->cvs_exclude;
		pThreadData->update_only = pParentData->update_only;
		pThreadData->inplace = pParentData->inplace;
		pThreadData->keep_dirlinks = pParentData->keep_dirlinks;
		pThreadData->preserve_links = pParentData->preserve_links;
		pThreadData->copy_links = pParentData->copy_links;
		pThreadData->whole_file = pParentData->whole_file;
		pThreadData->copy_unsafe_links = pParentData->copy_unsafe_links;
		pThreadData->preserve_hard_links = pParentData->preserve_hard_links;
		pThreadData->preserve_perms = pParentData->preserve_perms;
		pThreadData->preserve_devices = pParentData->preserve_devices;
		pThreadData->preserve_uid = pParentData->preserve_uid;
		pThreadData->preserve_gid = pParentData->preserve_gid;
		pThreadData->preserve_times = pParentData->preserve_times;
		pThreadData->always_checksum = pParentData->always_checksum;
		pThreadData->recurse = pParentData->recurse;
		pThreadData->relative_paths = pParentData->relative_paths;
		pThreadData->am_root = pParentData->am_root;
		pThreadData->opt_ignore_existing = pParentData->opt_ignore_existing;
		pThreadData->make_backups = pParentData->make_backups;
		pThreadData->ignore_times = pParentData->ignore_times;
		pThreadData->size_only = pParentData->size_only;

		pThreadData->pFixDirPathRtn = 0;
	}
	else
	{
		pThreadData->io_multiplexing_in = 0;
		pThreadData->io_multiplexing_out = 0;
		pThreadData->iobuf_out = NULL;
		pThreadData->iobuf_out_cnt = 0;
		pThreadData->iobuf_in = NULL;
		pThreadData->iobuf_in_siz = 0;
		pThreadData->iobuf_in_remaining = 0;
		pThreadData->iobuf_in_ndx = 0;
		pThreadData->no_flush = 0;
		pThreadData->msg_fd_in = -1;
		pThreadData->old_msg_fd_in = -1;
		pThreadData->msg_fd_out = -1;
		pThreadData->thread_fd_in = -1;
		pThreadData->thread_fd_out = -1;
		pThreadData->sock_f_in = -1;
		pThreadData->sock_f_out = -1;
		memset(&pThreadData->stats, 0, sizeof(struct stats_struct));
		pThreadData->tag_table=NULL;
		pThreadData->targets=NULL;
		pThreadData->curr_dir[0] = 0; //initialize the string to zero length.
		pThreadData->curr_dir_len = 0;
		
		pThreadData->exclude_list.head = 0;
		pThreadData->exclude_list.tail = 0;
		pThreadData->exclude_list.debug_type = "";

		pThreadData->local_exclude_list.head = 0;
		pThreadData->local_exclude_list.tail = 0;
		pThreadData->local_exclude_list.debug_type = "per-dir .cvsignore ";

		pThreadData->server_exclude_list.head = 0;
		pThreadData->server_exclude_list.tail = 0;
		pThreadData->server_exclude_list.debug_type = "server ";

		pThreadData->exclude_path_prefix = NULL;

		pThreadData->csum_length=2; /* initial value */
		pThreadData->checksum_seed=0;
		pThreadData->protocol_version=PROTOCOL_VERSION;
		pThreadData->sumresidue=0;
		memset(&pThreadData->sumrbuf, 0, sizeof(pThreadData->sumrbuf));
		memset(&pThreadData->md, 0, sizeof(pThreadData->md));
		pThreadData->last_match = 0;

		pThreadData->last_match = 0;
		pThreadData->last_byte = 0;
		pThreadData->last_sparse = 0;
		pThreadData->m = 0;
		pThreadData->wf_writeBuf = 0;
		pThreadData->wf_writeBufSize = 0;
		pThreadData->wf_writeBufCnt = 0;
		pThreadData->srt_residue = 0;
		pThreadData->srt_buf = 0;
		pThreadData->sdt_init_done = 0;
		pThreadData->sdt_flush_pending = 0;
		pThreadData->rdt_init_done = 0;
		pThreadData->rdt_saved_flag = 0;
		pThreadData->cs2_buf1 = 0;
		pThreadData->cs2_len1 = 0;
		pThreadData->pc = 0;
		pThreadData->bufr = 0;
		pThreadData->bSize = 0;
		pThreadData->received_flist = 0;
		pThreadData->rsync_module_argv = 0;
		pThreadData->rsync_module_argc = 0;
		pThreadData->parm_table = dup_new_parm_table(NULL);
		pThreadData->ServicePtrs = NULL;
		pThreadData->iNumServices = 0;
		pThreadData->iServiceIndex = 0;
		pThreadData->bInGlobalSection = True;
		pThreadData->pstartrecvfilesstruct = NULL;
		pThreadData->pstartfnstruct = NULL;
		pThreadData->io_timeout = 0;
		pThreadData->long_options = dup_options(NULL);
		pThreadData->cleanup_got_literal = 0;	
		pThreadData->cleanup_fname = 0;
		pThreadData->cleanup_new_fname = 0;
		pThreadData->cleanup_file = 0;		
		pThreadData->cleanup_fd_r = 0;
		pThreadData->cleanup_fd_w = 0;
		pThreadData->cleanup_pid = 0;
		pThreadData->verbose = 0;
		pThreadData->inside_cleanup = 0;
		pThreadData->last_io = 0;
		pThreadData->msg_list_push_written = 0;
		pThreadData->io_error = 0;
		//pThreadData->bwlimit_prior_tv = 0;
		pThreadData->bwlimit_total_written = 0;
		//pThreadData->bwlimit_tv = 0;
		//pThreadData->bwlimit_start_tv = 0;
		pThreadData->bwlimit_elapsed_usec = 0;
		pThreadData->bwlimit_sleep_usec = 0;
		pThreadData->am_sender = 0;

		pThreadData->sfe_modtime = 0;
		pThreadData->sfe_mode = 0;
		pThreadData->sfe_dev = 0;
		pThreadData->sfe_rdev = 0;
		pThreadData->sfe_rdev_major = 0;
		pThreadData->sfe_uid = 0;
		pThreadData->sfe_gid = 0;		
		//pThreadData->sfe_lastname //cleared by memset don't bother clearing it again.

		pThreadData->rfe_modtime = 0;
		pThreadData->rfe_mode = 0;
		pThreadData->rfe_dev = 0;
		pThreadData->rfe_rdev = 0;
		pThreadData->rfe_rdev_major = 0;
		pThreadData->rfe_uid = 0;
		pThreadData->rfe_gid = 0;
		//pThreadData->rfe_lastname //cleared by memset don't bother clearing it again.
		pThreadData->rfe_lastdir = 0;
		pThreadData->rfe_lastdir_depth = 0;
		pThreadData->rfe_lastdir_len = -1;

		pThreadData->dry_run = 0;
		pThreadData->sparse_files = 0;
		pThreadData->cvs_exclude = 0;
		pThreadData->update_only = 0;
		pThreadData->inplace = 0;
		pThreadData->keep_dirlinks = 0;
		pThreadData->preserve_links = 0;
		pThreadData->copy_links = 0;
		pThreadData->whole_file = -1;
		pThreadData->copy_unsafe_links = 0;
		pThreadData->preserve_hard_links = 0;
		pThreadData->preserve_perms = 0;
		pThreadData->preserve_devices = 0;
		pThreadData->preserve_uid = 0;
		pThreadData->preserve_gid = 0;
		pThreadData->preserve_times = 0;
		pThreadData->always_checksum = 0;
		pThreadData->recurse = 0;
		pThreadData->relative_paths = 0;
		pThreadData->am_root = 0;
		pThreadData->opt_ignore_existing = 0;
		pThreadData->make_backups = 0;
		pThreadData->ignore_times = 0;
		pThreadData->size_only = 0;

		pThreadData->pFixDirPathRtn = 0;
	}

	pThreadData->flag_ptr[0] = &pThreadData->recurse;
	pThreadData->flag_ptr[1] = &pThreadData->preserve_uid;
	pThreadData->flag_ptr[2] = &pThreadData->preserve_gid;
	pThreadData->flag_ptr[3] = &pThreadData->preserve_links;
	pThreadData->flag_ptr[4] = &pThreadData->preserve_devices;
	pThreadData->flag_ptr[5] = &pThreadData->preserve_hard_links;
	pThreadData->flag_ptr[6] = &pThreadData->always_checksum;

	return pThreadData;
}

/*
  GMM - 3/16/2005
  Free thread specific data for this thread.
*/
void FreeThreadData(void)
{
	char strDebug[256];
	struct thread_data * pData = GetThreadDataRaw();
	if( pData )
	{
		if( pData->iobuf_out != NULL )
		{
			free(pData->iobuf_out);
			pData->iobuf_out = NULL;
		}

		if( pData->iobuf_in != NULL )
		{
			free(pData->iobuf_in);
			pData->iobuf_in = NULL;
		}

		while (pData->msg_list_head) 
		{
			struct msg_list *ml = pData->msg_list_head;
			if( ml->buf )
				free(ml->buf);				
			pData->msg_list_head = ml->next;					
			free(ml);				
		}

		while (pData->redo_list_head) 
		{
			struct redo_list *rl = pData->redo_list_head;					
			pData->redo_list_head = rl->next;					
			free(rl);				
		}

		if( pData->msg_fd_in != INVALID_SOCKET )
		{
			sprintf(strDebug, "TID=0x%X closing %d in %s line %d\n", GetCurrentThreadId(), pData->msg_fd_in, __FILE__, __LINE__);
			OutputDebugString(strDebug);
			closesocket(pData->msg_fd_in);
		}

		if( pData->msg_fd_out != INVALID_SOCKET &&
			pData->msg_fd_out != pData->msg_fd_in )
		{
			sprintf(strDebug, "TID=0x%X closing %d in %s line %d\n", GetCurrentThreadId(), pData->msg_fd_out, __FILE__, __LINE__);
			OutputDebugString(strDebug);
			closesocket(pData->msg_fd_out);
		}

		if( pData->thread_fd_in != INVALID_SOCKET &&
			pData->thread_fd_in != pData->msg_fd_in &&
			pData->thread_fd_in != pData->msg_fd_out )
		{
			sprintf(strDebug, "TID=0x%X closing %d in %s line %d\n", GetCurrentThreadId(), pData->thread_fd_in, __FILE__, __LINE__);
			OutputDebugString(strDebug);
			closesocket(pData->thread_fd_in);
		}

		if( pData->thread_fd_out != INVALID_SOCKET &&
			pData->thread_fd_out != pData->msg_fd_in && 
			pData->thread_fd_out != pData->msg_fd_out && 
			pData->thread_fd_out != pData->thread_fd_in )
		{
			sprintf(strDebug, "TID=0x%X closing %d in %s line %d\n", GetCurrentThreadId(), pData->thread_fd_out, __FILE__, __LINE__);
			OutputDebugString(strDebug);
			closesocket(pData->thread_fd_out);
		}

		if( pData->sock_f_in != INVALID_SOCKET &&
			pData->sock_f_in != pData->msg_fd_in &&
			pData->sock_f_in != pData->msg_fd_out && 
			pData->sock_f_in != pData->thread_fd_in &&
			pData->sock_f_in != pData->thread_fd_out )
		{
			sprintf(strDebug, "TID=0x%X closing %d in %s line %d\n", GetCurrentThreadId(), pData->sock_f_in, __FILE__, __LINE__);
			OutputDebugString(strDebug);
			closesocket(pData->sock_f_in);
		}
		else if( pData->old_msg_fd_in != INVALID_SOCKET &&
			pData->old_msg_fd_in != pData->msg_fd_in &&
			pData->old_msg_fd_in != pData->msg_fd_out && 
			pData->old_msg_fd_in != pData->thread_fd_in &&
			pData->old_msg_fd_in != pData->thread_fd_out )
		{
			sprintf(strDebug, "TID=0x%X closing %d in %s line %d\n", GetCurrentThreadId(), pData->old_msg_fd_in, __FILE__, __LINE__);
			OutputDebugString(strDebug);
			closesocket(pData->old_msg_fd_in);
		}

		if( pData->sock_f_out != INVALID_SOCKET &&
			pData->sock_f_out != pData->msg_fd_in && 
			pData->sock_f_out != pData->msg_fd_out && 
			pData->sock_f_out != pData->thread_fd_in &&
			pData->sock_f_out != pData->thread_fd_out &&
			pData->sock_f_out != pData->sock_f_in )
		{
			sprintf(strDebug, "TID=0x%X closing %d in %s line %d\n", GetCurrentThreadId(), pData->sock_f_out, __FILE__, __LINE__);
			OutputDebugString(strDebug);
			closesocket(pData->sock_f_out);
		}

		if( pData->tag_table != NULL )
			free(pData->tag_table);

		if( pData->targets != NULL )
			free(pData->targets);

		clear_exclude_list(&pData->exclude_list);
		clear_exclude_list(&pData->local_exclude_list);
		clear_exclude_list(&pData->server_exclude_list);
	
		if( pData->exclude_path_prefix != NULL )
			free(pData->exclude_path_prefix);

		if( pData->cs2_buf1 != NULL )
			free(pData->cs2_buf1);

		if( pData->pc != NULL )
		{
			poptResetContext((poptContext)pData->pc);
			poptFreeContext((poptContext)pData->pc); //GMM - Don't leak pc.
		}

		if( pData->bufr != NULL )
			free(pData->bufr);

		if( pData->received_flist != NULL )
		{
			flist_free(pData->received_flist);
		}

		// GMM - argv is getting leaked.
		if( pData->rsync_module_argv )
		{
			while(pData->rsync_module_argc > 1)
			{
				if( pData->rsync_module_argv[pData->rsync_module_argc-1] )
					free(pData->rsync_module_argv[pData->rsync_module_argc-1]);

				pData->rsync_module_argc--;
			}
			free(pData->rsync_module_argv);
		}

		free_parm_table(pData->parm_table);

		free_services(pData->ServicePtrs, pData->iNumServices);

		if( pData->pstartrecvfilesstruct )
		{
			if(	(pData->pstartrecvfilesstruct->hDone != INVALID_HANDLE_VALUE) &&
				(pData->pstartrecvfilesstruct->hDone != NULL))
			{
				CloseHandle(pData->pstartrecvfilesstruct->hDone);
			}
			GlobalFree(pData->pstartrecvfilesstruct);
		}

		if( pData->pstartfnstruct )
		{
			if(  pData->pstartfnstruct->iParams[0] != INVALID_SOCKET )
			{
				sprintf(strDebug, "TID=0x%X closing %d in %s line %d\n", GetCurrentThreadId(), pData->pstartfnstruct->iParams[0], __FILE__, __LINE__);
				OutputDebugString(strDebug);	
				closesocket( pData->pstartfnstruct->iParams[0]);
			}

			if(	 pData->pstartfnstruct->iParams[1] !=  pData->pstartfnstruct->iParams[0] && 
				 pData->pstartfnstruct->iParams[0] != INVALID_SOCKET )
			{
				sprintf(strDebug, "TID=0x%X closing %d in %s line %d\n", GetCurrentThreadId(), pData->pstartfnstruct->iParams[1], __FILE__, __LINE__);
				OutputDebugString(strDebug);	
				closesocket( pData->pstartfnstruct->iParams[1]);
			}

			GlobalFree(pData->pstartfnstruct);
		}

		free_options(pData->long_options);

		if( pData->cleanup_fname )
			free(pData->cleanup_fname);

		//GMM - This is causing an access violation.
		//if( pData->cleanup_new_fname )
		//	free(pData->cleanup_new_fname);
		//
		// Until this can be fixed properly only free if it is a valid ptr.
		if( pData->cleanup_new_fname && !IsBadReadPtr(pData->cleanup_new_fname, 1) && !IsBadWritePtr(pData->cleanup_new_fname, 1) )
			free(pData->cleanup_new_fname);

		//GMM - This is causing an access violation too...
		//if( pData->cleanup_file )
		//	free(pData->cleanup_file);
		//
		// Until this can be fixed properly only free if it is a valid ptr.
		if( pData->cleanup_file && !IsBadReadPtr(pData->cleanup_file, 1) && !IsBadWritePtr(pData->cleanup_file, 1))
			free(pData->cleanup_file);

		if( pData->rfe_lastdir )
			free(pData->rfe_lastdir);

		if( pData->pFixDirPathRtn )
			free(pData->pFixDirPathRtn);

		GlobalFree(pData);
		pData = NULL;
		TlsSetValue(g_dwTLSIndex, pData);
	}
}