#include <rsync.h> //GMM
#define curr_dir GetThreadData()->curr_dir //GMM
#define curr_dir_len GetThreadData()->curr_dir_len //GMM

char * fixdirpath(const char * orig_name)
{
    char * name = orig_name;
    char * new_name = NULL;

    if( GetThreadData()->pFixDirPathRtn )
    {
	    free(GetThreadData()->pFixDirPathRtn);	    
    }

    if(name && name[0])
    {
		size_t base_length = strlen(name);

		if( name[0] == '.' && name[1] == '/' )
		{
			name = &orig_name[2];
			base_length -= 2;
		}
		else if( name[0] == '.' && name[1] == 0 )
		{
			name = &orig_name[1];
			base_length--;
		}

		if( name[0] != '/' )
		{
			base_length += curr_dir_len;	
			if( curr_dir[curr_dir_len-1] != '/' )
			{
				base_length++;
			}
		}

		if(	(new_name = (char *) malloc(base_length + 1)) != 0)
		{
			if( name[0] != '/' )
			{
				strcpy(new_name, curr_dir);
				if( new_name[curr_dir_len-1] != '/' )
				{
					new_name[curr_dir_len] = '/';
					new_name[curr_dir_len+1] = 0;
				}
			}
			else
			{
				strcpy(new_name, name);
			}			
		}

    }

    GetThreadData()->pFixDirPathRtn = new_name;

    return new_name;
}