#include <rsync.h>

void CreateEnvironment(void)
{
	HKEY hk; 

	if (RegCreateKey(HKEY_LOCAL_MACHINE, _T("Environment"), &hk))
	{
		return; //Couldn't create key
	}

	RegCloseKey(hk); 
} 

void winceinit(void)
{
	CreateEnvironment();
	XCESetEnvironmentVariableInRegA("UNIXROOTDIR", "\\DiskOnChip");
	xceinit(NULL);	
}

