/* 
   Copyright (C) 2005 by George McCollister
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <rsync.h>

//
// George McCollister
//
// This is a socketpair implementation for Win32 that uses TCP to pass data.
//
int socketpair(int d, int type, int protocol, int sv[2])
{
	SOCKET hsockClient;
	SOCKET hsockListen;
	SOCKADDR_IN SockAddr;
	SOCKADDR_IN RemoteAddr;	

	int nRet;
	int nLen;

	DWORD dwArg = 1;
#if defined(WIN32) && defined(_DEBUG)
	char strDebug[256];
#endif

	//WSADATA	wsaData;
	//WSAStartup(0x0101, &wsaData);
	
	//init socket
	hsockListen = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if( hsockListen == INVALID_SOCKET )
	{
		printf("socket() failed!\n");
		return -1;
	}
#if defined(WIN32) && defined(_DEBUG)
	else
	{
		sprintf(strDebug, "TID=0x%X opening socket %d in %s line %d\n", GetCurrentThreadId(), hsockListen, __FILE__, __LINE__);
		OutputDebugString(strDebug);
	}
#endif

	//socket configuration
	SockAddr.sin_port = htons(0);
	SockAddr.sin_family = AF_INET;
	SockAddr.sin_addr.S_un.S_addr = inet_addr("127.0.0.1"); 
	
	//bind to port
	nRet = bind(hsockListen, 
				(LPSOCKADDR)&SockAddr,
				sizeof(struct sockaddr)
				);
	if(nRet == SOCKET_ERROR)
	{
		printf("bind() failed!\n");
		closesocket(hsockListen);
		return -1;
	}

	//listen for connections
	nRet = listen(hsockListen, 1);
	if (nRet == SOCKET_ERROR)
	{
		printf("listen() failed!\n");
		closesocket(hsockListen);
		return -1;
	}

	nRet = sizeof(SockAddr);
	if( getsockname(hsockListen, (PSOCKADDR) &SockAddr, &nRet) == SOCKET_ERROR )
	{
		printf("Couldn't get socket info.\n");
		return -1;
	}
	
	dwArg=1;
	nRet = ioctlsocket(hsockListen, FIONBIO, &dwArg);
	if (nRet == SOCKET_ERROR)
	{
		printf("ioctlsocket() failed!\n");
		return -1;
	}

/// Init second socket
	hsockClient = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (hsockClient == INVALID_SOCKET)
	{
		return -1;
	}
#if defined(WIN32) && defined(_DEBUG)
	else
	{
		sprintf(strDebug, "TID=0x%X opening socket %d in %s line %d\n", GetCurrentThreadId(), hsockClient, __FILE__, __LINE__);
		OutputDebugString(strDebug);
	}
#endif
		
	RemoteAddr.sin_family = AF_INET;
	RemoteAddr.sin_port = SockAddr.sin_port;
	RemoteAddr.sin_addr.s_addr = inet_addr("127.0.0.1");

	dwArg=1;
	nRet = ioctlsocket(hsockClient, FIONBIO, &dwArg);
	if (nRet == SOCKET_ERROR)
	{
		printf("ioctlsocket() failed!\n");
		return -1;
	}
	
/// Establish a connection.
	nRet = connect(hsockClient, (LPSOCKADDR) &RemoteAddr, sizeof(RemoteAddr));

	if( nRet == SOCKET_ERROR )
	{
		switch( WSAGetLastError() )
		{
		case WSAEWOULDBLOCK:
			break;
		default:
			printf("connect() failed! Error %d.\n", WSAGetLastError());
			return -1;
		}	
	}

	do
	{

		nLen = sizeof(SOCKADDR_IN);
		sv[0] = (int) accept(hsockListen, (LPSOCKADDR)&RemoteAddr, &nLen);

		if( sv[0] == INVALID_SOCKET )
		{
			switch( WSAGetLastError() )
			{
			case WSAEWOULDBLOCK:
				Sleep(10);
				break;
			default:
				printf("accept() failed! Error %d.\n", WSAGetLastError());
				return -1;
			}	
		}
#if defined(WIN32) && defined(_DEBUG)
		else
		{
			sprintf(strDebug, "TID=0x%X accepting socket %d in %s line %d\n", GetCurrentThreadId(), sv[0], __FILE__, __LINE__);
			OutputDebugString(strDebug);
		}
#endif
	}
	while( sv[0] == INVALID_SOCKET );

	sv[1] = hsockClient;

	if( hsockListen != INVALID_SOCKET )
	{
#if defined(WIN32) && defined(_DEBUG)
		sprintf(strDebug, "TID=0x%X closing %d in %s line %d\n", GetCurrentThreadId(), hsockListen, __FILE__, __LINE__);
		OutputDebugString(strDebug);
#endif
		closesocket(hsockListen);
	}

	return 0;
}