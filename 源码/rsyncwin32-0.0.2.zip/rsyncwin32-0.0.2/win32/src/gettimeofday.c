/* 
   Copyright (C) 2005 by George McCollister
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <rsync.h>

//GMM - Secs/uSecs from 1/1/1970 00:00:00 using Win32
int gettimeofday(struct timeval * tv, void * tz)
{
	SYSTEMTIME stCurrent;
	SYSTEMTIME stEpoch;
	FILETIME ftCurrent;
	FILETIME ftEpoch;
	LARGE_INTEGER liCurrent;
	LARGE_INTEGER liEpoch;
	LARGE_INTEGER liDifference;
	DWORD dwRtn=0;

	stEpoch.wYear = 1970;
	stEpoch.wMonth = 1;
	stEpoch.wDay = 1;
	stEpoch.wHour = 0;
	stEpoch.wMinute = 0;
	stEpoch.wSecond = 0;
	stEpoch.wMilliseconds = 0;
	stEpoch.wDayOfWeek = 0;

	GetSystemTime(&stCurrent);

	SystemTimeToFileTime(&stCurrent, &ftCurrent);
	SystemTimeToFileTime(&stEpoch, &ftEpoch);
	
	memcpy((LPBYTE)&liCurrent.QuadPart + 0, &ftCurrent.dwLowDateTime, sizeof(ftCurrent.dwLowDateTime));
	memcpy((LPBYTE)&liCurrent.QuadPart + sizeof(DWORD), &ftCurrent.dwHighDateTime, sizeof(ftCurrent.dwHighDateTime));

	memcpy((LPBYTE)&liEpoch.QuadPart + 0, &ftEpoch.dwLowDateTime, sizeof(ftEpoch.dwLowDateTime));
	memcpy((LPBYTE)&liEpoch.QuadPart + sizeof(DWORD), &ftEpoch.dwHighDateTime, sizeof(ftEpoch.dwHighDateTime));

	liDifference.QuadPart = liCurrent.QuadPart - liEpoch.QuadPart;
	tv->tv_usec = (long) (liDifference.QuadPart % 10000000) / 10; //convert from 100-nano sec to 1 usec
	liDifference.QuadPart /= 10000000;
	tv->tv_sec = (long) liDifference.QuadPart;
	
	return 0; //success
}