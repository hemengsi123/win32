#include <rsync.h>

#define curr_dir GetThreadData()->curr_dir
#define curr_dir_len GetThreadData()->curr_dir_len

#if HAVE_OFF64_T

int tstat64(const char *fname, STRUCT_STAT *st)
{
	int iLen = 0;
	char fullpath[MAXPATHLEN];
	if( fname[0] != '/' )
	{
		strncpy(fullpath, curr_dir, sizeof(fullpath)-2);
		iLen = strlen(fullpath);
		if( fullpath[iLen-1] != '/' )
		{
			fullpath[iLen++] = '/';
			fullpath[iLen] = 0;
		}
		strncat(fullpath, fname, sizeof(fullpath) - 1 - iLen);
		return _stati64(fullpath, st);
	}
	else
	{
		return _stati64(fname, st);
	}
}

#else

int tstat(const char *fname, STRUCT_STAT *st)
{
	int iLen = 0;
	char fullpath[MAXPATHLEN];
	if( fname[0] != '/' )
	{
		strncpy(fullpath, curr_dir, sizeof(fullpath)-2);
		iLen = strlen(fullpath);
		if( fullpath[iLen-1] != '/' )
		{
			fullpath[iLen++] = '/';
			fullpath[iLen] = 0;
		}
		strncat(fullpath, fname, sizeof(fullpath) - 1 - iLen);
		return stat(fullpath, st);
	}
	else
	{
		return stat(fname, st);
	}
}

#endif