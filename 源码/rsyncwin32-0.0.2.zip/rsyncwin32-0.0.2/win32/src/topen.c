#include <rsync.h>

#define curr_dir GetThreadData()->curr_dir
#define curr_dir_len GetThreadData()->curr_dir_len

char * unixtodospath(char * strPath)
{
/*
	int iCnt=0;
	int iLen = strlen(strPath);

	for(iCnt=0; iCnt < iLen; iCnt++)
	{
		if( strPath[iCnt] == '/' )
			strPath[iCnt] = '\\';
	}
*/
	return strPath;
}

//int open( const char *filename, int oflag, ... )
int topen( const char *filename, int oflag, int pmode )
{
	int iLen = 0;
	char fullpath[MAXPATHLEN];
	if( filename[0] != '/' )
	{
		strncpy(fullpath, curr_dir, sizeof(fullpath)-2);
		iLen = strlen(fullpath);
		if( fullpath[iLen-1] != '/' )
		{
			fullpath[iLen++] = '/';
			fullpath[iLen] = 0;
		}
		strncat(fullpath, filename, sizeof(fullpath) - 1 - iLen);
		return _open(unixtodospath(fullpath), oflag, pmode);
	}
	else
	{
		strncpy(fullpath, filename, sizeof(fullpath)-2);
		return _open(unixtodospath(fullpath), oflag, pmode);
	}
}