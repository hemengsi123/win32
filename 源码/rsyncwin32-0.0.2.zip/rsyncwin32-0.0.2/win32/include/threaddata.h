/* 
   Copyright (C) 2005 by George McCollister
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

typedef struct
{
	struct thread_data * pParentData;
	HANDLE hDone;
	int f_in;
	struct file_list *flist;
	char *local_name;
	int fdpipe;	
} startrecvfilesstruct;

typedef struct
{
	struct thread_data * pParentData;
	int (*fn)(int, int);
	int iParams[2];
} startfnstruct;

struct thread_data {
	int io_multiplexing_out;
	int io_multiplexing_in;
	char *iobuf_out;
	int iobuf_out_cnt;
	char *iobuf_in;
	size_t iobuf_in_siz;
	size_t iobuf_in_remaining;
	size_t iobuf_in_ndx;
	struct redo_list *redo_list_head;
	struct redo_list *redo_list_tail;
	struct msg_list *msg_list_head;
	struct msg_list *msg_list_tail;
	int no_flush;
	int old_msg_fd_in;
	int msg_fd_in;
	int msg_fd_out;
	int thread_fd_in;
	int thread_fd_out;
	int sock_f_in;
	int sock_f_out;
	struct stats_struct stats;
	size_t *tag_table;
	struct target *targets;
	char curr_dir[MAXPATHLEN];
	unsigned int curr_dir_len;
	struct exclude_list_struct exclude_list;
	struct exclude_list_struct local_exclude_list;
	struct exclude_list_struct server_exclude_list;
	char *exclude_path_prefix;
	int csum_length;
	int checksum_seed;
	int protocol_version;
	int sumresidue;
	char sumrbuf[CSUM_CHUNK];
	struct mdfour md;
	OFF_T last_match;
	char last_byte;
	int last_sparse;
	struct mdfour *m;
	char *wf_writeBuf;
	size_t wf_writeBufSize;
	size_t wf_writeBufCnt;
	int srt_residue;
	char * srt_buf;
	int sdt_init_done;
	int sdt_flush_pending;
	int rdt_init_done;
	int rdt_saved_flag;
	char *cs2_buf1;
	int cs2_len1;
	void * pc;
	char *bufr;
	int   bSize;
	struct file_list *received_flist;
	char ** rsync_module_argv;
	int rsync_module_argc;
	void * parm_table;
	void **ServicePtrs;
	int iNumServices;
	int iServiceIndex;
	BOOL bInGlobalSection;
	startrecvfilesstruct * pstartrecvfilesstruct;
	startfnstruct * pstartfnstruct;
	int io_timeout;
	void * long_options;
	int cleanup_got_literal;
	char *cleanup_fname;
	char *cleanup_new_fname;
	struct file_struct *cleanup_file;
	int cleanup_fd_r;
	int cleanup_fd_w;
	pid_t cleanup_pid;
	int verbose;
	int inside_cleanup;
	time_t last_io;
	int msg_list_push_written;
	int io_error;
	
	struct timeval bwlimit_prior_tv;
	long bwlimit_total_written; 
	struct timeval bwlimit_tv;
	struct timeval bwlimit_start_tv;
	long bwlimit_elapsed_usec;
	long bwlimit_sleep_usec;
	int am_sender;

	time_t sfe_modtime;
	mode_t sfe_mode;
	uint64 sfe_dev;
	dev_t sfe_rdev;
	uint32 sfe_rdev_major;
	uid_t sfe_uid;
	gid_t sfe_gid;
	char sfe_lastname[MAXPATHLEN];

	time_t rfe_modtime;
	mode_t rfe_mode;
	uint64 rfe_dev;
	dev_t rfe_rdev;
	uint32 rfe_rdev_major;
	uid_t rfe_uid;
	gid_t rfe_gid;
	char rfe_lastname[MAXPATHLEN];
	char * rfe_lastdir;
	int rfe_lastdir_depth;
	int rfe_lastdir_len;

	int dry_run;
	int sparse_files;
	int cvs_exclude;
	int update_only;
	int inplace;
	int keep_dirlinks;
	int preserve_links;
	int copy_links;
	int whole_file;
	int copy_unsafe_links;
	int preserve_hard_links;
	int preserve_perms;
	int preserve_devices;
	int preserve_uid;
	int preserve_gid;
	int preserve_times;
	int always_checksum;
	int recurse;
	int relative_paths;
	int am_root;
	int opt_ignore_existing;
	int make_backups;
	int ignore_times;
	int size_only;
	
	int *flag_ptr[8];

	char * pFixDirPathRtn;
};

struct thread_data * GetThreadData(void);
struct thread_data * GetThreadDataRaw(void);
struct thread_data * CreateThreadDataFromParent(struct thread_data * pParentData);
void FreeThreadData(void);